package com.example.businessdirectory.fragments;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.businessdirectory.R;
import com.example.businessdirectory.adapter.CompanyAdapter;
import com.example.businessdirectory.database.AppDatabase;
import com.example.businessdirectory.model.Company;

import java.util.List;

public class CategoryFragment extends Fragment {

    private static final String ARG_CATEGORY = "category";
    private String category;
    private AppDatabase db;
    private CompanyAdapter adapter;
    private ListView listView;

    public static CategoryFragment newInstance(String category) {
        CategoryFragment fragment = new CategoryFragment();
        Bundle args = new Bundle();
        args.putString(ARG_CATEGORY, category);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_category, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        category = getArguments().getString(ARG_CATEGORY);
        db = AppDatabase.getInstance(getContext());

        listView = view.findViewById(R.id.listView);
        EditText searchField = view.findViewById(R.id.searchField);

        loadData();

        searchField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                List<Company> filtered = db.companyDao()
                        .searchByCategory(category, s.toString());
                adapter.updateList(filtered);
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        loadData();
    }

    private void loadData() {
        List<Company> companyList = db.companyDao().getByCategory(category);
        if (adapter == null) {
            adapter = new CompanyAdapter(getContext(), companyList);
            listView.setAdapter(adapter);
        } else {
            adapter.updateList(companyList);
        }
    }
}