package com.example.businessdirectory;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.businessdirectory.database.AppDatabase;
import com.example.businessdirectory.model.Company;

import java.util.ArrayList;
import java.util.List;

public class AddCompanyActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_company);

        // Стрелка за враќање
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Button btnSave = findViewById(R.id.btnSave);
        btnSave.setOnClickListener(v -> {
            Company company = new Company();
            company.name = ((EditText) findViewById(R.id.etName))
                    .getText().toString();
            company.address = ((EditText) findViewById(R.id.etAddress))
                    .getText().toString();
            company.email = ((EditText) findViewById(R.id.etEmail))
                    .getText().toString();
            company.phone = ((EditText) findViewById(R.id.etPhone))
                    .getText().toString();
            company.website = ((EditText) findViewById(R.id.etWebsite))
                    .getText().toString();

            String lat = ((EditText) findViewById(R.id.etLatitude))
                    .getText().toString();
            String lng = ((EditText) findViewById(R.id.etLongitude))
                    .getText().toString();
            company.latitude = lat.isEmpty() ? 0 : Double.parseDouble(lat);
            company.longitude = lng.isEmpty() ? 0 : Double.parseDouble(lng);

            List<String> categories = new ArrayList<>();
            if (((CheckBox) findViewById(R.id.cbIndustry)).isChecked())
                categories.add("Industry");
            if (((CheckBox) findViewById(R.id.cbFun)).isChecked())
                categories.add("Fun");
            if (((CheckBox) findViewById(R.id.cbEducation)).isChecked())
                categories.add("Education");
            if (((CheckBox) findViewById(R.id.cbServices)).isChecked())
                categories.add("Services");
            company.category = TextUtils.join(",", categories);

            if (company.name.isEmpty()) {
                Toast.makeText(this, "Внесете назив!", Toast.LENGTH_SHORT).show();
                return;
            }
            if (categories.isEmpty()) {
                Toast.makeText(this, "Изберете категорија!", Toast.LENGTH_SHORT).show();
                return;
            }

            AppDatabase.getInstance(this).companyDao().insert(company);
            Toast.makeText(this, "Компанијата е зачувана!", Toast.LENGTH_SHORT).show();
            finish();
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}