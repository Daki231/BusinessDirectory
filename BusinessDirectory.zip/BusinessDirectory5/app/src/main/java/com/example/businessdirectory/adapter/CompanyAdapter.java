package com.example.businessdirectory.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.businessdirectory.R;
import com.example.businessdirectory.model.Company;

import java.util.List;

public class CompanyAdapter extends BaseAdapter {

    private Context context;
    private List<Company> companies;

    public CompanyAdapter(Context context, List<Company> companies) {
        this.context = context;
        this.companies = companies;
    }

    public void updateList(List<Company> newList) {
        companies = newList;
        notifyDataSetChanged();
    }

    @Override
    public int getCount() { return companies.size(); }

    @Override
    public Object getItem(int pos) { return companies.get(pos); }

    @Override
    public long getItemId(int pos) { return pos; }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context)
                    .inflate(R.layout.list_item_company, parent, false);
        }
        Company c = companies.get(position);
        ((TextView) convertView.findViewById(R.id.companyName)).setText(c.name);
        ((TextView) convertView.findViewById(R.id.companyAddress)).setText(c.address);
        ((TextView) convertView.findViewById(R.id.companyPhone)).setText(c.phone);
        ((TextView) convertView.findViewById(R.id.companyWebsite)).setText(c.website);

        ImageView logo = convertView.findViewById(R.id.companyLogo);

        if (c.category != null && c.category.contains("Services")) {
            logo.setImageResource(android.R.drawable.ic_menu_call);
        } else if (c.category != null && c.category.contains("Fun")) {
            logo.setImageResource(android.R.drawable.ic_menu_compass);
        } else if (c.category != null && c.category.contains("Industry")) {
            logo.setImageResource(android.R.drawable.ic_menu_manage);
        } else if (c.category != null && c.category.contains("Education")) {
            logo.setImageResource(android.R.drawable.ic_menu_info_details);
        } else {
            logo.setImageResource(android.R.drawable.ic_menu_myplaces);
        }

        return convertView;
    }
}