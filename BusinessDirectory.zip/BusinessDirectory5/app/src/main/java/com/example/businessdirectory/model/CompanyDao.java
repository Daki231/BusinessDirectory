package com.example.businessdirectory.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.businessdirectory.model.Company;

import java.util.List;

@Dao
public interface CompanyDao {

    @Insert
    void insert(Company company);

    @Query("SELECT * FROM companies WHERE category LIKE '%' || :category || '%'")
    List<Company> getByCategory(String category);

    @Query("SELECT * FROM companies WHERE category LIKE '%' || :category || '%' AND name LIKE '%' || :search || '%'")
    List<Company> searchByCategory(String category, String search);
}