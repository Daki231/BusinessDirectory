package com.example.businessdirectory.adapter;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.example.businessdirectory.fragments.CategoryFragment;

public class ViewPagerAdapter extends FragmentStateAdapter {

    public ViewPagerAdapter(FragmentActivity fa) {
        super(fa);
    }

    @Override
    public Fragment createFragment(int position) {
        switch (position) {
            case 0: return CategoryFragment.newInstance("Services");
            case 1: return CategoryFragment.newInstance("Fun");
            case 2: return CategoryFragment.newInstance("Industry");
            default: return CategoryFragment.newInstance("Education");
        }
    }

    @Override
    public int getItemCount() { return 4; }
}